local shot = false
local check = false
local check2 = false
local count = 0
local scopedWeapons = 
{
    100416529,  -- WEAPON_SNIPERRIFLE
    205991906,  -- WEAPON_HEAVYSNIPER
    -952879014, -- WEAPON_MARKSMANRIFLE
	177293209,   -- WEAPON_HEAVYSNIPER MKII
	1785463520,  -- WEAPON_MARKSMANRIFLE_MK2
}

Citizen.CreateThread(function()
	local tykitys = false
    while true do
        Citizen.Wait( 5 )
        if IsPedShooting(GetPlayerPed(-1)) and GetFollowPedCamViewMode() ~= 4 then
            if GetSelectedPedWeapon(PlayerPedId()) == GetHashKey('WEAPON_PETROLCAN') then
                Citizen.Wait(500)
            else
				SetFollowPedCamViewMode(4)
				DisableControlAction(0, 0, true)
                Citizen.Wait(2500)
                tykitys = true
            end
        end

		if IsPlayerFreeAiming(PlayerId()) then
			BlockWeaponWheelThisFrame()
            SetFollowPedCamViewMode(4)
			SetFollowVehicleCamViewMode(4)
			DisableControlAction(0, 37, true)
			DisableControlAction(0, 0, true)
            tykitys = true
		end

		if IsControlPressed(0, 91) and GetLastInputMethod(0) then
			SetFollowVehicleCamViewMode(4)
		end

        if tykitys then
            if not IsPlayerFreeAiming(PlayerId()) and not IsPedShooting(GetPlayerPed(-1)) then
                SetFollowVehicleCamViewMode(1)
                SetFollowPedCamViewMode(1)
                tykitys = false
            end
        end
    end
end)

Citizen.CreateThread(function()
    local ampuminen = true
    local nopeus = 0
    local alfa = false
        while true do
            Citizen.Wait(100)
    
            if IsPedInAnyVehicle(PlayerPedId(), true) then
                nopeus = GetEntitySpeed(GetVehiclePedIsIn(PlayerPedId(), false))
                if nopeus > 14 and ampuminen then
                    SetPlayerCanDoDriveBy(PlayerId(), false)
                    ampuminen = false
                elseif nopeus < 14 and not ampuminen then
                    SetPlayerCanDoDriveBy(PlayerId(), true)
                    ampuminen = true
                end
    
                if nopeus > 3 and IsPedDoingDriveby(PlayerPedId()) and not alfa then
                    ShakeGameplayCam("ROAD_VIBRATION_SHAKE", 20.0)
                    alfa = true
                elseif not IsPedDoingDriveby(PlayerPedId()) and alfa then
                    StopGameplayCamShaking( true )
                    alfa = false
                end
    
                if nopeus > 5 and IsPedDoingDriveby(PlayerPedId()) and not alfa then
                    ShakeGameplayCam("ROAD_VIBRATION_SHAKE", 450.0)
                    alfa = true
                elseif not IsPedDoingDriveby(PlayerPedId()) and alfa then
                    StopGameplayCamShaking( true )
                    alfa = false
                end
    
                if nopeus > 8 and IsPedDoingDriveby(PlayerPedId()) and not alfa then
                    ShakeGameplayCam("ROAD_VIBRATION_SHAKE", 650.0)
                    alfa = true
                elseif not IsPedDoingDriveby(PlayerPedId()) and alfa then
                    StopGameplayCamShaking( true )
                    alfa = false
                end
    
                if nopeus > 10 and IsPedDoingDriveby(PlayerPedId()) and not alfa then
                    ShakeGameplayCam("ROAD_VIBRATION_SHAKE", 850.0)
                    alfa = true
                elseif not IsPedDoingDriveby(PlayerPedId()) and alfa then
                    StopGameplayCamShaking( true )
                    alfa = false
                end
    
                if nopeus > 12 and IsPedDoingDriveby(PlayerPedId()) and not alfa then
                    ShakeGameplayCam("ROAD_VIBRATION_SHAKE", 1050.0)
                    alfa = true
                elseif not IsPedDoingDriveby(PlayerPedId()) and alfa then
                    StopGameplayCamShaking( true )
                    alfa = false
                end
            else
                Citizen.Wait(2000)
            end
        end
    end) 

--[[Citizen.CreateThread(function()
	while true do
		SetBlackout(false)
		Citizen.Wait( 1 )
		if IsPlayerFreeAiming(PlayerId()) then
		    if GetFollowPedCamViewMode() == 4 and check == false then
			    check = false
			else
				SetFollowPedCamViewMode(4)
				SetFollowVehicleCamViewMode(4)
			    check = true
			end
		else
		    if check == true then
				SetFollowPedCamViewMode(1)
				SetFollowVehicleCamViewMode(1)
				check = false
			end
		end
	end
end ) --]]


--[[Citizen.CreateThread(function()
	while true do
		SetBlackout(false)
		Citizen.Wait( 1 )
		
		if IsPedShooting(GetPlayerPed(-1)) and shot == false and GetFollowPedCamViewMode() ~= 4 then
			check2 = true
			shot = true
			SetFollowPedCamViewMode(4)
			SetFollowVehicleCamViewMode(4)
		end
		
		if IsPedShooting(GetPlayerPed(-1)) and shot == true and GetFollowPedCamViewMode() == 4 then
			count = 0
		end
		
		if not IsPedShooting(GetPlayerPed(-1)) and shot == true then
		    count = count + 1
		end

        if not IsPedShooting(GetPlayerPed(-1)) and shot == true then
			if not IsPedShooting(GetPlayerPed(-1)) and shot == true and count > 20 then
		        if check2 == true then
				    check2 = false
					shot = false
					SetFollowPedCamViewMode(1)
				end
			end
		end	    
	end
end ) --]]

function HashInTable( hash )
    for k, v in pairs( scopedWeapons ) do 
        if ( hash == v ) then 
            return true 
        end 
    end 

    return false 
end 

function ManageReticle()
    local ped = GetPlayerPed( -1 )
    local _, hash = GetCurrentPedWeapon( ped, true )
        if not HashInTable( hash ) then 
            HideHudComponentThisFrame( 14 )
		end 
end 


Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
		local ped = GetPlayerPed( -1 )
		local weapon = GetSelectedPedWeapon(ped)
		--print(weapon) -- To get the weapon hash by pressing F8 in game
		
		-- Disable reticle
		
		ManageReticle()
		
		-- Disable melee while aiming (may be not working)
		
		if IsPedArmed(ped, 6) then
        	DisableControlAction(1, 140, true)
            DisableControlAction(1, 141, true)
            DisableControlAction(1, 142, true)
        end
		
		-- Disable ammo HUD
		
		DisplayAmmoThisFrame(false)
		
		-- Shakycam
		
		-- Pistol --
        
		if weapon == GetHashKey("WEAPON_STUNGUN") then
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.01)
			end
		end
		
		if weapon == GetHashKey("WEAPON_FLAREGUN") then	
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.01)
			end
		end
		
		if weapon == GetHashKey("WEAPON_SNSPISTOL") then		
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.02)
			end
		end
		
		if weapon == GetHashKey("WEAPON_SNSPISTOL_MK2") then		
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.025)
			end
		end
		
		if weapon == GetHashKey("WEAPON_PISTOL") then		
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.025)
			end
		end
		
		if weapon == GetHashKey("WEAPON_PISTOL_MK2") then
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.03)
			end
		end
		
		if weapon == GetHashKey("WEAPON_APPISTOL") then
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.05)
			end
		end
		
		if weapon == GetHashKey("WEAPON_COMBATPISTOL") then		
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.03)
			end
		end
		
		if weapon == GetHashKey("WEAPON_PISTOL50") then
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.09)
			end
		end
		
		if weapon == GetHashKey("WEAPON_HEAVYPISTOL") then		
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.04)
			end
		end
		
		if weapon == GetHashKey("WEAPON_VINTAGEPISTOL") then		
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.03)
			end
		end
		
		if weapon == GetHashKey("WEAPON_MARKSMANPISTOL") then		
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.03)
			end
		end
		
		if weapon == GetHashKey("WEAPON_REVOLVER") then	
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.09)
			end
		end
		
		if weapon == GetHashKey("WEAPON_REVOLVER_MK2") then	
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.10)
			end
		end
		
		if weapon == GetHashKey("WEAPON_DOUBLEACTION") then	
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.05)
			end
		end

		-- SMG --
		
		if weapon == GetHashKey("WEAPON_MICROSMG") then	
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.045)
			end
		end
		
		if weapon == GetHashKey("WEAPON_COMBATPDW") then			
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.045)
			end
		end
		
		if weapon == GetHashKey("WEAPON_SMG") then
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.055)
			end
		end
		
		if weapon == GetHashKey("WEAPON_SMG_MK2") then	
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.055)
			end
		end
		
		if weapon == GetHashKey("WEAPON_ASSAULTSMG") then	
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.050)
			end
		end
		
		if weapon == GetHashKey("WEAPON_MACHINEPISTOL") then		
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.035)
			end
		end
		
		if weapon == GetHashKey("WEAPON_MINISMG") then
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.035)
			end
		end
		
		if weapon == GetHashKey("WEAPON_MG") then
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.07)
			end
		end
		
		if weapon == GetHashKey("WEAPON_COMBATMG") then		
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.08)
			end
		end
		
		if weapon == GetHashKey("WEAPON_COMBATMG_MK2") then			
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.085)
			end
		end
		
		-- Rifles --
		
		if weapon == GetHashKey("WEAPON_ASSAULTRIFLE") then			
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.07)
			end
		end
		
		if weapon == GetHashKey("WEAPON_ASSAULTRIFLE_MK2") then			
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.075)
			end
		end
		
		if weapon == GetHashKey("WEAPON_CARBINERIFLE") then	
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.07)
			end
		end
		
		if weapon == GetHashKey("WEAPON_CARBINERIFLE_MK2") then			
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.07)
			end
		end
		
		if weapon == GetHashKey("WEAPON_ADVANCEDRIFLE") then		
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.06)
			end
		end
		
		if weapon == GetHashKey("WEAPON_GUSENBERG") then		
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.06)
			end
		end
		
		if weapon == GetHashKey("WEAPON_SPECIALCARBINE") then		
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.06)
			end
		end
		
		if weapon == GetHashKey("WEAPON_SPECIALCARBINE_MK2") then		
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.075)
			end
		end
		
		if weapon == GetHashKey("WEAPON_BULLPUPRIFLE") then			
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.05)
			end
		end
		
		if weapon == GetHashKey("WEAPON_BULLPUPRIFLE_MK2") then			
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.065)
			end
		end
		
		if weapon == GetHashKey("WEAPON_COMPACTRIFLE") then		
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.05)
			end
		end
		
		-- Shotgun --
		
		if weapon == GetHashKey("WEAPON_PUMPSHOTGUN") then
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.07)
			end
		end
		
		if weapon == GetHashKey("WEAPON_PUMPSHOTGUN_MK2") then
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.085)
			end
		end
		
		if weapon == GetHashKey("WEAPON_SAWNOFFSHOTGUN") then
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.06)
			end
		end
		
		if weapon == GetHashKey("WEAPON_ASSAULTSHOTGUN") then	
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.12)
			end
		end
		
		if weapon == GetHashKey("WEAPON_BULLPUPSHOTGUN") then		
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.08)
			end
		end
		
		if weapon == GetHashKey("WEAPON_DBSHOTGUN") then	
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.05)
			end
		end
		
		if weapon == GetHashKey("WEAPON_AUTOSHOTGUN") then	
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.08)
			end
		end
		
		if weapon == GetHashKey("WEAPON_MUSKET") then
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.3)
			end
		end
		
		if weapon == GetHashKey("WEAPON_HEAVYSHOTGUN") then	
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.13)
			end
		end
		
		-- Sniper --
		
		if weapon == GetHashKey("WEAPON_SNIPERRIFLE") then
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.2)
			end
		end
		
		if weapon == GetHashKey("WEAPON_HEAVYSNIPER") then	
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.3)
			end
		end
		
		if weapon == GetHashKey("WEAPON_HEAVYSNIPER_MK2") then
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.35)
			end
		end
		
		if weapon == GetHashKey("WEAPON_MARKSMANRIFLE") then			
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.1)
			end
		end
		
		if weapon == GetHashKey("WEAPON_MARKSMANRIFLE_MK2") then			
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.1)
			end
		end
		
		-- Launcher --
		
		if weapon == GetHashKey("WEAPON_GRENADELAUNCHER") then		
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.08)
			end
		end
		
		if weapon == GetHashKey("WEAPON_RPG") then
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.9)
			end
		end
		
		if weapon == GetHashKey("WEAPON_HOMINGLAUNCHER") then		
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.9)
			end
		end
		
		if weapon == GetHashKey("WEAPON_MINIGUN") then	
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.20)
			end
		end
		
		if weapon == GetHashKey("WEAPON_RAILGUN") then	
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 1.0)
				
			end
		end
		
		if weapon == GetHashKey("WEAPON_COMPACTLAUNCHER") then		
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.08)
			end
		end
		
		if weapon == GetHashKey("WEAPON_FIREWORK") then	
			if IsPedShooting(ped) then
				ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.5)
			end
		end
		
		-- Infinite FireExtinguisher --
		
		--[[if weapon == GetHashKey("WEAPON_FIREEXTINGUISHER") then		
			if IsPedShooting(ped) then
				SetPedInfiniteAmmo(ped, true, GetHashKey("WEAPON_FIREEXTINGUISHER"))
			end
		end ]] -- jätä nuo tohon!
	end
end)

-- recoil script by bluethefurry / Blumlaut https://forum.fivem.net/t/betterrecoil-better-3rd-person-recoil-for-fivem/82894
-- I just added some missing weapons because of the doomsday update adding some MK2.
-- I can't manage to make negative hashes works, if someone make it works, please let me know =)

local recoils = {

	-- Pistols --
 	[-1076751822] 	= 0.20, 	-- SNS PISTOL
	[-2009644972] 	= 0.20, 	-- SNS PISTOL MK2
	[453432689] 	= 1.30, 	-- PISTOL
	[-1075685676] 	= 0.20, 	-- PISTOL MK2
	[137902532] 	= 0.20, 	-- VINTAGE PISTOL
	[1593441988] 	= 0.20, 	-- COMBAT PISTOL
	[-771403250] 	= 0.21, 	-- HEAVY PISTOL
	[-1716589765] 	= 0.25, 	-- PISTOL .50
	[584646201] 	= 0.10, 	-- AP PISTOL
	[-1045183535] 	= 0.30, 	-- REVOLVER
	[-879347409] 	= 0.30, 	-- REVOLVER MK2
	[-1746263880] 	= 0.30, 	-- DOUBLE ACTION REVOLVER
	[-598887786] 	= 0.90, 	-- MARKSMAN PISTOL
	[1198879012] 	= 0.90, 	-- FLARE GUN
	[911657153] 	= 0.10, 	-- STUN GUN

	-- Small Machine Guns SMG --
	[324215364] 	= 0.17, 	-- MICRO SMG
	[736523883] 	= 0.11, 	-- SMG
	[2024373456] 	= 0.17, 	-- SMG MK2
	[-270015777] 	= 0.13, 	-- ASSAULT SMG
	[171789620] 	= 0.10, 	-- COMBAT PDW
	[-619010992] 	= 0.14, 	-- MACHINE PISTOL
	[-1121678507] 	= 0.12, 	-- MINI SMG	
	[1627465347] 	= 0.18, 	-- GUSENBERG

	-- MG --
	[-1660422300] 	= 0.10, 	-- MG
	[2144741730] 	= 0.10, 	-- COMBAT MG
	[-608341376] 	= 0.10, 	-- COMBAT MG MK2
	[1119849093] 	= 0.01, 	-- MINIGUN

	-- Assault Rifles (AR) --
	[-1074790547] 	= 0.16, 	-- ASSAULT RIFLE
	[961495388] 	= 0.13, 	-- ASSAULT RIFLE MK2
	[-2084633992] 	= 0.10, 	-- CARBINE RIFLE
	[-86904375] 	= 0.10, 	-- CARBINE RIFLE MK2
	[-1357824103] 	= 0.10, 	-- ADVANCED RIFLE
	[2132975508] 	= 0.20, 	-- BULLPUP RIFLE
	[-2066285827] 	= 0.21, 	-- BULLPUP RIFLE MK2
	[-1063057011] 	= 0.20, 	-- SPECIAL CARBINE
	[-1768145561] 	= 0.20,		-- SPECIAL CARBINE MK2
	[1649403952] 	= 0.17,		-- COMPACT RIFLE
	
	-- Shotguns --
	[487013001] 	= 0.30, 	-- PUMP SHOTGUN
	[1432025498] 	= 0.30, 	-- PUMP SHOTGUN MK2
	[2017895192] 	= 0.30, 	-- SAWNOFF SHOTGUN
	[-494615257] 	= 0.30, 	-- ASSAULT SHOTGUN
	[-1654528753] 	= 0.20, 	-- BULLPUP SHOTGUN
	[-275439685] 	= 0.20, 	-- DOUBLE BARREL SHOTGUN
	[317205821] 	= 0.25, 	-- AUTO SHOTGUN
	[984333226] 	= 0.25, 	-- HEAVY SHOTGUN

	-- Snipers --
	[100416529] 	= 0.40, 	-- SNIPER RIFLE
	[205991906] 	= 0.50,		-- HEAVY SNIPER
	[177293209] 	= 0.50, 	-- HEAVY SNIPER MK2
	[856002082] 	= 1.20, 	-- REMOTE SNIPER
	[-1466123874] 	= 0.30, 	-- MUSKET	
	[-952879014] 	= 0.30, 	-- MARKSMAN RIFLE
	[1785463520] 	= 0.35, 	-- MARKSMAN RIFLE MK2
	
	-- Boom boom --
	[1672152130] 	= 0.00,		-- HOMING LAUNCHER
	[1834241177] 	= 0.50,		-- RAILGUN
	[2726580491] 	= 1.00,		-- GRENADE LAUNCHER
	[1305664598] 	= 1.00,		-- GRENADE LAUNCHER SMOKE
	[2982836145] 	= 0.00,		-- RPG
	[1752584910] 	= 0.00,		-- STINGER
	[125959754] 	= 0.50,		-- COMPACT LAUNCHER

	--[[
    [453432689]     = 0.3,      -- PISTOL
 
    [-1075685676]   = 0.3,      -- PISTOL MK2
 
    [1593441988]    = 0.3,      -- COMBAT PISTOL
 
    [-1716589765]   = 1.0,      -- PISTOL .50
 
    [-1076751822]   = 0.1,      -- SNS PISTOL
 
    [-2009644972] 	= 0.1, 		-- SNS PISTOL MK2
 
    [-771403250]    = 0.2,      -- HEAVY PISTOL
 
    [137902532]     = 0.2,      -- VINTAGE PISTOL
 
    [-598887786]    = 4.7,      -- MARKSMAN PISTOL
 
    [-1045183535]   = 3.0,      -- REVOLVER
 
    [-879347409]    = 2.1,      -- REVOLVER MK2
 
    [584646201]     = 0.2,      -- AP PISTOL
 
    [-1746263880]   = 2.1,      -- DOUBLEACTION REVOLVER
 
    [911657153]     = 0.2,      -- TAZER
 
 
    --//-- SMGT
 
    [324215364]     = 0.2,      -- MICRO SMG
 
    [736523883]     = 0.1,      -- SMG
 
    [2024373456]    = 0.1,      -- SMG MK2
 
    [-1121678507]   = 0.05,      -- MINISMG
 
    [-270015777]    = 0.1,      -- ASSAULTSMG
 
    [-619010992]    = 0.1,      -- MACHINE PISTOL
 
    [171789620]     = 0.05,      -- COMBAT PDW
 
 
    --//-- RIFLET
 
    [-1074790547]   = 0.1,      -- ASSAULT RIFLE
 
    [961495388]     = 0.1,		-- ASSAULT RIFLE MK2
 
    [-2084633992]   = 0.05, 	-- CARBINE RIFLE 	
 
    [-86904375]     = 0.1,      -- CARBINE RIFLE MK2
 
    [-1357824103]   = 0.1,      -- ADVANCED RIFLE
 
    [-1063057011]   = 0.1,      -- SPECIAL CARBINE
 
    [-1768145561]   = 0.1,      -- SPECIAL CARBINE MK2
 
    [2132975508]    = 0.1,      -- BULLPUP RIFLE
 
    [-2066285827]   = 0.1,      -- BULLPUP RIFLE MK2
 
    [1649403952]    = 0.1,      -- COMPACT RIFLE
 
 
    --//-- LMGT
 
    [-1660422300]   = 0.0,      -- MG
 
    [2144741730]    = 0.0,      -- COMBATMG
 
    [-608341376]    = 0.0,      -- COMBATMG MK2
 
    [1627465347]    = 0.2,      -- GUSENBERG
 
 
    --//-- HAULIKOT
 
    [487013001]     = 0.1,     -- PUMP SHOTGUN
 
    [1432025498]    = 0.1, 		-- PUMP SHOTGUN MK2
 
    [2017895192]    = 0.1, 		-- SAWNOFF SHOTGUN
 
    [-1654528753]   = 0.1, 		-- BULLPUP SHOTGUN
 
    [-494615257]    = 0.1, 		-- ASSAULT SHOTGUN
 
    [-1466123874]   = 3.1, 		-- MUSKET
 
    [984333226]     = 0.1, 		-- HEAVY SHOTGUN
 
    [-275439685]    = 0.0, 		-- DOUBLE BARREL SHOTGUN
 
    [317205821]     = 0.1,		-- SWEEPER SHOTGUN
 
 
    --//-- SNIPERIT
 
    [100416529]     = 1.5, 		-- SNIPER RIFLE
 
    [205991906]     = 2.0, 		-- HEAVY SNIPER
 
    [177293209]     = 0.0,		-- HEAVY SNIPER MK2
 
    [-952879014]    = 1.7,      -- MARKSMAN RIFLE
 
    [1785463520]    = 0.1,      -- MARKSMAN RIFLE MK2
 
 
    --//-- MUUT
 
    [-1568386805]   = 0.1,      -- GRENADE LAUNCHER
 
    [-1312131151]   = 1.1,      -- RPG
 
    [1119849093]    = 0.0,      -- MINIGUN
 
    [2138347493]    = 0.5, 		-- FIREWORK LAUNCHER
 
    [1834241177]    = 0.5, 		-- RAILGUN
 
	[1672152130]    = 0.1, 		-- HOMING LAUNCHER	
	--]]
}

-- Recoil --
Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
		if IsPedShooting(PlayerPedId()) then
			local _,wep = GetCurrentPedWeapon(PlayerPedId())
			_,cAmmo = GetAmmoInClip(PlayerPedId(), wep)
			if recoils[wep] and recoils[wep] ~= 0 then
				tv = 0
				repeat 
					Wait(0)
					p = GetGameplayCamRelativePitch()
					y = GetGameplayCamRelativeHeading()
					local py
					if GetFollowPedCamViewMode() == 4 and not IsPedDoingDriveby(PlayerPedId()) then
						
					elseif IsPedDoingDriveby(PlayerPedId()) and GetFollowVehicleCamViewMode() == 4 then
						py = math.random(-300, 300)/100
							SetGameplayCamRelativeHeading(y+py)
					end
					SetGameplayCamRelativePitch(p+0.1, 0.2)
										
					tv = tv+0.1
				until tv >= recoils[wep]
			end
			
		end
	end
end)