client_scripts {
  'config.lua',
  'main.lua'
}