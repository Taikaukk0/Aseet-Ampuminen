ESX = nil 

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

-- LUOTILIIVIT

ESX.RegisterUsableItem('luotiliivi', function(source)
    local xPlayer = ESX.GetPlayerFromId(source)

    xPlayer.removeInventoryItem('luotiliivi', 1)
    TriggerClientEvent('luotiliivi:luotiliivi', source)
end)

RegisterNetEvent('returnItem')
AddEventHandler('returnItem', function(item)
    local xPlayer = ESX.GetPlayerFromId(source)

    xPlayer.addInventoryItem(item, 1)
end)

-- SILU

ESX.RegisterUsableItem('silu', function(source)
	local _source  = source
	local xPlayer  = ESX.GetPlayerFromId(_source)
    TriggerClientEvent('eden_accesories:use', source, 'silu')
	xPlayer.removeInventoryItem('silu', 1)
end)

RegisterServerEvent('eden_accesories:giveBack')
AddEventHandler('eden_accesories:giveBack', function(item)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	xPlayer.addInventoryItem(item, 1)
end)

