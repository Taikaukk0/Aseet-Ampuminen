INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES
('luotiliivi', 'Luotiliivi', 10, 0, 1),
('silu', 'Äänenvaimennin', 10, 0, 1),
;