ESX = nil
local IsDead = false

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
    PlayerData = xPlayer
end)

RegisterNetEvent('luotiliivi:luotiliivi')
AddEventHandler('luotiliivi:luotiliivi', function()
    local inventory = ESX.GetPlayerData().inventory
    local ped = GetPlayerPed(-1)
    local armor = GetPedArmour(ped)
    local item = 'luotiliivi'

    if(armor >= 100) or (armor+1 > 100) then
        exports['mythic_notify']:DoHudText('inform', 'Sinulla on jo luotiliivi päällä!')
        TriggerServerEvent('returnItem', item)
        return
    end 
    ExecuteCommand( "e adjust" )
    TriggerEvent("mythic_progbar:client:progress", {
        name = "unique_action_name",
        duration = 6000,
        label = "Puet luotiliiviä...",
        useWhileDead = false,
        canCancel = true,
        controlDisables = {
            disableMovement = true,
            disableCarMovement = true,
            disableMouse = false,
            disableCombat = true,
        },
        animation = {
            animDict = "missheistdockssetup1clipboard@idle_a",
            anim = "idle_a",
        },
        prop = {
            model = "prop_armour_pickup",
        }
    },  function(status)
        if not status then
            SetPedArmour(ped, 100)
            exports['mythic_notify']:DoHudText('inform', 'Puit luotiliivin päällesi.')
            TriggerEvent('luotiliivi:laitavaatteet')
        end
    end)
end)

RegisterCommand("luottaripois",function()
	luottaripois()
end)

function table.includes(table, element)
    for _, value in pairs(table) do
        if value == element then
            return true
        end
    end
    return false
end

-- SILU

local weapons = {
    [GetHashKey('WEAPON_PISTOL')] = { silu = GetHashKey('component_at_pi_supp_02') },
    [GetHashKey('WEAPON_PISTOL50')] = { silu = GetHashKey('COMPONENT_AT_AR_SUPP_02') },
    [GetHashKey('WEAPON_COMBATPISTOL')] = { silu = GetHashKey('COMPONENT_AT_PI_SUPP') },
    [GetHashKey('WEAPON_APPISTOL')] = { silu = GetHashKey('COMPONENT_AT_PI_SUPP') },
    [GetHashKey('WEAPON_HEAVYPISTOL')] = { silu = GetHashKey('COMPONENT_AT_PI_SUPP') },
    [GetHashKey('WEAPON_VINTAGEPISTOL')] = { silu = GetHashKey('COMPONENT_AT_PI_SUPP') },
    [GetHashKey('WEAPON_SMG')] = { silu = GetHashKey('COMPONENT_AT_PI_SUPP') },
    [GetHashKey('WEAPON_MICROSMG')] = { silu = GetHashKey('COMPONENT_AT_AR_SUPP_02') },
    [GetHashKey('WEAPON_ASSAULTSMG')] = { silu = GetHashKey('COMPONENT_AT_AR_SUPP_02') },
    [GetHashKey('WEAPON_ASSAULTRIFLE')] = { silu = GetHashKey('COMPONENT_AT_AR_SUPP_02') },
    [GetHashKey('WEAPON_CARBINERIFLE')] = { silu = GetHashKey('COMPONENT_AT_AR_SUPP') },
    [GetHashKey('WEAPON_ADVANCEDRIFLE')] = { silu = GetHashKey('COMPONENT_AT_AR_SUPP') },
    [GetHashKey('WEAPON_SPECIALCARBINE')] = { silu = GetHashKey('COMPONENT_AT_AR_SUPP_02') },
    [GetHashKey('WEAPON_BULLPUPRIFLE')] = { silu = GetHashKey('COMPONENT_AT_AR_SUPP') },
    [GetHashKey('WEAPON_ASSAULTSHOTGUN')] = { silu = GetHashKey('COMPONENT_AT_AR_SUPP') },
    [GetHashKey('WEAPON_HEAVYSHOTGUN')] = { silu = GetHashKey('COMPONENT_AT_AR_SUPP_02') },
    [GetHashKey('WEAPON_BULLPUPSHOTGUN')] = { silu = GetHashKey('COMPONENT_AT_AR_SUPP_02') },
    [GetHashKey('WEAPON_PUMPSHOTGUN')] = { silu = GetHashKey('COMPONENT_AT_SR_SUPP') },
    [GetHashKey('WEAPON_MARKSMANRIFLE')] = { silu = GetHashKey('COMPONENT_AT_AR_SUPP') },
    [GetHashKey('WEAPON_SNIPERRIFLE')] = { silu = GetHashKey('COMPONENT_AT_AR_SUPP_02') },
    [GetHashKey('WEAPON_COMBATPDW')] = { silu = nil }
}

-- Use item
RegisterNetEvent('eden_accesories:use')
AddEventHandler('eden_accesories:use', function( type )
    if weapons[GetSelectedPedWeapon(PlayerPedId())] and weapons[GetSelectedPedWeapon(PlayerPedId())][type] then
        if not HasPedGotWeaponComponent(GetPlayerPed(-1), GetSelectedPedWeapon(PlayerPedId()), weapons[GetSelectedPedWeapon(PlayerPedId())][type]) then
            ExecuteCommand( "e uncuff" )
            palkki22223()
            Citizen.Wait(4000)
            ClearPedTasksImmediately(GetPlayerPed(-1))
            GiveWeaponComponentToPed(GetPlayerPed(-1), GetSelectedPedWeapon(PlayerPedId()), weapons[GetSelectedPedWeapon(PlayerPedId())][type])  
            ESX.ShowNotification(string.format('%s %s', "Kiinnitit osan : ", type))
        else
            RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetSelectedPedWeapon(PlayerPedId()), weapons[GetSelectedPedWeapon(PlayerPedId())][type])  
            ESX.ShowNotification(string.format('%s %s', "Irrotit osan : ", type))
        end
    else
        ESX.ShowNotification(string.format('%s %s %s', ' ', type, " ei mahdu aseeseesi.."))
    end
end)

RegisterCommand("siluirti",function()
	otavittuun()
end)

function otavittuun()
    if weapons[GetSelectedPedWeapon(PlayerPedId())] then
        for k,v in pairs(weapons) do
            if GetSelectedPedWeapon(PlayerPedId()) == k then
                if HasPedGotWeaponComponent(GetPlayerPed(-1), GetSelectedPedWeapon(PlayerPedId()), v.silu) then
                    ExecuteCommand( "e uncuff" )
                    palkki22222()
                    Citizen.Wait(4000)
                    ClearPedTasksImmediately(GetPlayerPed(-1))
                    TriggerServerEvent('eden_accesories:giveBack', 'silu')
                    ESX.ShowNotification("Irrotit äänenvaimentimen!")
                    RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetSelectedPedWeapon(PlayerPedId()), v.silu)
                end
            end
        end
    end
end

function palkki22222()
    TriggerEvent("mythic_progbar:client:progress", {
        name = "unique_action_name",
        duration = 3800,
        label = "Irrotat silua",
        useWhileDead = false,
        canCancel = true,
        controlDisables = {
            disableMovement = true,
            disableCarMovement = true,
            disableMouse = false,
            disableCombat = true,
        },
    }, function(status)
        if not status then
        end
    end)
end

function palkki22223()
    TriggerEvent("mythic_progbar:client:progress", {
        name = "unique_action_name",
        duration = 3800,
        label = "Kiinnität silua",
        useWhileDead = false,
        canCancel = true,
        controlDisables = {
            disableMovement = true,
            disableCarMovement = true,
            disableMouse = false,
            disableCombat = true,
        },
    }, function(status)
        if not status then
        end
    end)
end

-- LUOTTAREIDEN VAATE


RegisterNetEvent('luotiliivi:laitavaatteet')
AddEventHandler('luotiliivi:laitavaatteet', function()
	TriggerEvent('skinchanger:getSkin', function(skin)
	

		local clothesSkin = {
		['bproof_1'] = 27, ['bproof_2'] = 5,
		}
		TriggerEvent('skinchanger:loadClothes', skin, clothesSkin)
	end)
end)


function luottaripois()
    ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin)
        TriggerEvent('skinchanger:loadSkin', skin)
    end)
    local ped = GetPlayerPed(-1)
    SetPedArmour(ped, 0)
    ESX.ShowNotification("Heitit luotiliivisi maahan.")
end